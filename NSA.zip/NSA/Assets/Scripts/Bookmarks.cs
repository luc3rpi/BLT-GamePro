﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bookmarks : MonoBehaviour {
    public List<GameObject> fileBook;
    // Use this for initialization
    private void Awake()
    {
        fileBook = new List<GameObject>();
    }
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
